import json
import datetime
import requests
import os
from google.cloud import storage
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

def main():
    """
    Função principal que será executada pelo Cloud Run.
    """
    
    # --- Configurações ---
    BUCKET_NAME = "meu-bucket-dados"  # Substitua pelo nome do seu bucket
    DATA_PAGE_URL = "https://dados.pbh.gov.br/dataset/c071d227-2c97-40ae-b847-f31c5101a91e/resource/88101fac-7200-4476-8c4f-09e1663c435e"

    driver = None
    try:
        # --- Configurando as opções do navegador Chrome para modo headless ---
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        
        # --- Gerenciando o driver dinamicamente ---
        # Usa o webdriver-manager para obter o caminho do driver
        service = Service(ChromeDriverManager().install())
        
        # Acessa o navegador e o driver do sistema, instalados pelo Dockerfile
        driver = webdriver.Chrome(service=service, options=chrome_options)
        
        # --- Navega até a página de download ---
        driver.get(DATA_PAGE_URL)
        
        # Encontra o link de download para o formato JSON
        json_link = driver.find_element(By.LINK_TEXT, "JSON")
        download_url = json_link.get_attribute('href')
        
        # --- Baixa o conteúdo usando a URL encontrada ---
        print(f"URL de download encontrada: {download_url}")
        
        response = requests.get(download_url, timeout=30)
        response.raise_for_status()
        
        dados = response.json()

        # --- Salva no Cloud Storage ---
        rotulo_data = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        nome_arquivo = f"api_data_{rotulo_data}.json"

        storage_client = storage.Client()
        bucket = storage_client.bucket(BUCKET_NAME)
        blob = bucket.blob(nome_arquivo)

        blob.upload_from_string(
            data=json.dumps(dados, indent=4),
            content_type='application/json'
        )

        print(f"Arquivo {nome_arquivo} salvo com sucesso no bucket {BUCKET_NAME}.")

    except Exception as e:
        print(f"Ocorreu um erro: {e}")
        raise # Re-lança o erro para o Cloud Run capturá-lo
        
    finally:
        if driver:
            driver.quit()

if __name__ == "__main__":
    main()
